<?php
// Triuu child theme bootstrap (inert)
/* AI:start:noop */
if (!function_exists('tri_ai_noop_test')) {
    function tri_ai_noop_test() { return 'ok'; }
}
/* AI:end:noop */
