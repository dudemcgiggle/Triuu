<?php return array('dependencies' => array(), 'version' => 'd45683985595780d10ad');
